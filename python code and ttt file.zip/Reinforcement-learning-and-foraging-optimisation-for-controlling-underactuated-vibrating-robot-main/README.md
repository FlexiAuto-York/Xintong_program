This procedure and document is attached as an appendix to the dissertation
‘Reinforcement learning and foraging optimisation for controlling underactuated vibrating robot’




